# RepoPilot AI

Analyze a GitHub repository, browse its folder structure VS Code-style, and upload
files with AI-suggested destinations — committed straight to GitHub, with optional
branch creation and full rollback on failure.

## Prerequisites

- Node.js 20+
- PostgreSQL 14+ (running locally, or a hosted instance)
- A GitHub account
- (Optional) An Anthropic API key, for AI commit messages and destination suggestions

## 1. Install dependencies

```bash
npm install
```

## 2. Create a GitHub OAuth App

Go to https://github.com/settings/developers → **New OAuth App**, and fill in:

- **Homepage URL**: `http://localhost:3000`
- **Authorization callback URL**: `http://localhost:3000/api/auth/callback/github`

Copy the generated **Client ID** and **Client Secret** — you'll need them next.

## 3. Configure environment variables

```bash
cp .env.example .env
```

Fill in `.env`:

```bash
DATABASE_URL="postgresql://user:password@localhost:5432/repopilot"
GITHUB_CLIENT_ID="<from step 2>"
GITHUB_CLIENT_SECRET="<from step 2>"
AUTH_SECRET="<generate below>"
TOKEN_ENCRYPTION_KEY="<generate below>"
NEXTAUTH_URL="http://localhost:3000"
ANTHROPIC_API_KEY="<optional, from console.anthropic.com>"
```

Generate the two required secrets:

```bash
openssl rand -base64 32   # use for AUTH_SECRET
openssl rand -base64 32   # use for TOKEN_ENCRYPTION_KEY (must be a different value)
```

## 4. Set up the database

Create a local Postgres database (skip if using a hosted one):

```bash
createdb repopilot
```

Run migrations:

```bash
npx prisma migrate dev --name init
```

## 5. Run the app

```bash
npm run dev
```

Open **http://localhost:3000**, sign in with GitHub, paste a repository URL, and go.

## What works without an Anthropic API key

Everything except the two AI features. Without `ANTHROPIC_API_KEY` set:
- Commit messages fall back to a deterministic template (`Add 3 files to src/assets`).
- Destination suggestions fall back to simple rules (images → `assets/images`, README/LICENSE → root, everything else → root with low confidence).

Both features degrade gracefully rather than failing — you'll just lose the "smart" part.

## Project structure

```
prisma/schema.prisma        Database schema (users, accounts, sessions, jobs)
src/app/                    Next.js App Router pages + API routes
src/components/             React components (tree explorer, upload, auth)
src/lib/auth/                NextAuth config, encrypted token storage, session helpers
src/lib/github/              Octokit client, tree fetching, commit pipeline, retry/rollback
src/lib/ai/                  AI commit message + destination suggestion calls
src/hooks/                   Client-side state hooks
```

## Common issues

- **"No GitHub account linked for this user"** — sign out and back in; this means the
  OAuth callback didn't complete or the `Account` row wasn't created.
- **Prisma errors on first run** — make sure `DATABASE_URL` points to a database that
  exists (`createdb repopilot`) before running `prisma migrate dev`.
- **GitHub API 403 rate limit errors** — expected on very large repos analyzed
  repeatedly; the app already backs off automatically, just wait a minute.
- **`TOKEN_ENCRYPTION_KEY must decode to exactly 32 bytes`** — you likely pasted a
  key that wasn't generated with `openssl rand -base64 32`. Regenerate it.
