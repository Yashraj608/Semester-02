import { LoginButton } from "@/components/auth/login-button";

export default function LoginPage() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen gap-4">
      <h1 className="text-xl font-medium text-explorer-text">Sign in to RepoPilot AI</h1>
      <p className="text-[13px] text-explorer-muted">We only request read/write access to repositories you choose to work with.</p>
      <LoginButton />
    </main>
  );
}
