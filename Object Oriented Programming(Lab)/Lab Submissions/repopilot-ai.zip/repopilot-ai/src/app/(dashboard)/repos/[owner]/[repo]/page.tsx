import { RepoExplorerWithCommit } from "@/components/repo-explorer-with-commit";

interface PageProps {
  params: Promise<{ owner: string; repo: string }>;
  searchParams: Promise<{ branch?: string }>;
}

export default async function RepoPage({ params, searchParams }: PageProps) {
  const { owner, repo } = await params;
  const { branch } = await searchParams;

  return (
    <div className="flex flex-col gap-2">
      <h1 className="text-lg font-medium text-explorer-text">{owner}/{repo}</h1>
      <RepoExplorerWithCommit owner={owner} repo={repo} branch={branch ?? "main"} />
    </div>
  );
}
