"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function ReposPage() {
  const [repoUrl, setRepoUrl] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  async function handleAnalyze() {
    setError(null);
    setIsLoading(true);
    try {
      const res = await fetch("/api/repos/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repoUrl }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Failed to analyze repository");
        return;
      }

      router.push(`/repos/${data.repository.owner}/${data.repository.name}?branch=${data.branch}`);
    } catch {
      setError("Something went wrong — check the URL and try again");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto flex flex-col gap-3">
      <h1 className="text-lg font-medium text-explorer-text">Analyze a repository</h1>
      <p className="text-[13px] text-explorer-muted">
        Paste a GitHub repository URL to browse its structure and upload files.
      </p>
      <div className="flex gap-2">
        <input
          value={repoUrl}
          onChange={(e) => setRepoUrl(e.target.value)}
          placeholder="https://github.com/owner/repository"
          className="flex-1 bg-explorer-sidebar border border-explorer-border rounded-sm px-3 py-2 text-[13px] text-explorer-text"
          onKeyDown={(e) => e.key === "Enter" && handleAnalyze()}
        />
        <button
          onClick={handleAnalyze}
          disabled={!repoUrl || isLoading}
          className="bg-explorer-accent text-white px-4 py-2 rounded-sm text-[13px] disabled:opacity-50"
        >
          {isLoading ? "Analyzing…" : "Analyze"}
        </button>
      </div>
      {error && <p className="text-[13px] text-red-500">{error}</p>}
    </div>
  );
}
