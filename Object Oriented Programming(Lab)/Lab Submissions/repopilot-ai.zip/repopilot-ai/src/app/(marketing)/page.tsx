import { LoginButton } from "@/components/auth/login-button";

export default function LandingPage() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen gap-4 px-4 text-center">
      <h1 className="text-2xl font-medium text-explorer-text">RepoPilot AI</h1>
      <p className="text-[14px] text-explorer-muted max-w-md">
        Paste a GitHub repository URL, browse its folder structure, and commit new files
        with AI-suggested destinations — all without leaving the browser.
      </p>
      <LoginButton />
    </main>
  );
}
