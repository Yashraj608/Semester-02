import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { generateCommitMessage } from "@/lib/ai/generate-commit-message";

export async function POST(req: NextRequest) {
  await requireUser();

  const { files, targetFolder } = (await req.json()) as {
    files: { name: string; path: string; sizeBytes: number; textPreview?: string }[];
    targetFolder: string;
  };

  if (!files?.length) {
    return NextResponse.json({ error: "No files provided" }, { status: 400 });
  }

  const result = await generateCommitMessage({ files, targetFolder });
  return NextResponse.json(result, { status: 200 });
}
