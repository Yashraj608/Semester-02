import { NextRequest } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createGithubClient } from "@/lib/github/client";
import { getRepositoryMetadata } from "@/lib/github/repository";
import { commitFilesWithProgress, type FileResolution } from "@/lib/github/git-transaction";
import { isAllowedFile } from "@/lib/github/mime-validation";
import { CommitFailedError, BranchAlreadyExistsError } from "@/lib/github/commit-errors";

interface RouteParams {
  params: Promise<{ owner: string; repo: string }>;
}

export async function POST(req: NextRequest, { params }: RouteParams) {
  const user = await requireUser();
  const { owner, repo } = await params;

  const formData = await req.formData();
  const baseBranch = formData.get("branch") as string;
  const newBranchName = (formData.get("newBranchName") as string) || null;
  const commitMessage = (formData.get("commitMessage") as string) || "Upload files via RepoPilot AI";
  const fileDestinations: Record<string, string> = JSON.parse((formData.get("fileDestinations") as string) || "{}");
  const resolutions: Record<string, FileResolution> = JSON.parse((formData.get("resolutions") as string) || "{}");
  const files = formData.getAll("files") as File[];

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const emit = (event: object) => controller.enqueue(encoder.encode(JSON.stringify(event) + "\n"));

      try {
        for (const file of files) {
          const check = isAllowedFile(file);
          if (!check.ok) throw new Error(check.reason);
        }

        const octokit = await createGithubClient(user.id);
        await getRepositoryMetadata(octokit, owner, repo, "push");

        const result = await commitFilesWithProgress({
          octokit,
          owner,
          repo,
          baseBranch,
          newBranchName,
          fileDestinations,
          commitMessage,
          files,
          resolutions,
          emit,
        });

        emit({ type: "done", ...result });
      } catch (err) {
        if (err instanceof CommitFailedError) {
          emit({ type: "error", message: err.message, rolledBack: err.rolledBack });
        } else if (err instanceof BranchAlreadyExistsError) {
          emit({ type: "error", message: err.message, rolledBack: false });
        } else {
          const message = err instanceof Error ? err.message : "Commit failed";
          emit({ type: "error", message, rolledBack: false });
        }
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, { headers: { "Content-Type": "application/x-ndjson", "Cache-Control": "no-cache" } });
}
