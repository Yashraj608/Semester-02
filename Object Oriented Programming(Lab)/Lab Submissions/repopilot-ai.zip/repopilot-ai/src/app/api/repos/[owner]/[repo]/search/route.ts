import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createGithubClient } from "@/lib/github/client";
import { fetchFullTree } from "@/lib/github/tree";

interface RouteParams {
  params: Promise<{ owner: string; repo: string }>;
}

export async function GET(req: NextRequest, { params }: RouteParams) {
  await requireUser();
  const { owner, repo } = await params;

  const query = req.nextUrl.searchParams.get("q")?.trim().toLowerCase() ?? "";
  const branch = req.nextUrl.searchParams.get("branch");
  if (!query || !branch) {
    return NextResponse.json({ error: "Missing q or branch parameter" }, { status: 400 });
  }

  const user = await requireUser();
  const octokit = await createGithubClient(user.id);
  const { entries } = await fetchFullTree(octokit, owner, repo, branch);

  const matches = entries.filter((e) => e.path.toLowerCase().includes(query));

  const ancestorPaths = new Set<string>();
  for (const match of matches) {
    const segments = match.path.split("/");
    for (let i = 1; i < segments.length; i++) {
      ancestorPaths.add(segments.slice(0, i).join("/"));
    }
  }

  return NextResponse.json(
    { matches: matches.map((m) => ({ path: m.path, type: m.type })), ancestorPaths: Array.from(ancestorPaths) },
    { status: 200 }
  );
}
