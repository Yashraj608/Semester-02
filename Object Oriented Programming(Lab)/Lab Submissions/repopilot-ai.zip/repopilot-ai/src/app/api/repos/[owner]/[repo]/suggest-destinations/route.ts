import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createGithubClient } from "@/lib/github/client";
import { fetchFullTree } from "@/lib/github/tree";
import { buildFolderProfile } from "@/lib/github/folder-profile";
import { suggestDestinations } from "@/lib/ai/suggest-destinations";
import type { FileForSuggestion } from "@/types/ai-suggestions";

interface RouteParams {
  params: Promise<{ owner: string; repo: string }>;
}

export async function POST(req: NextRequest, { params }: RouteParams) {
  const user = await requireUser();
  const { owner, repo } = await params;

  const { files, branch } = (await req.json()) as { files: FileForSuggestion[]; branch: string };

  if (!files?.length) {
    return NextResponse.json({ error: "No files provided" }, { status: 400 });
  }

  const octokit = await createGithubClient(user.id);
  const { entries, truncated } = await fetchFullTree(octokit, owner, repo, branch);
  const folderProfile = buildFolderProfile(entries);

  const suggestions = await suggestDestinations(files, folderProfile, truncated);
  return NextResponse.json({ suggestions }, { status: 200 });
}
