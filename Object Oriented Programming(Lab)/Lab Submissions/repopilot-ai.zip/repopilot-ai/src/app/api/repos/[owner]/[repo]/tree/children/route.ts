import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createGithubClient } from "@/lib/github/client";
import { GithubApiError } from "@/lib/github/errors";

interface RouteParams {
  params: Promise<{ owner: string; repo: string }>;
}

export async function GET(req: NextRequest, { params }: RouteParams) {
  try {
    const user = await requireUser();
    const { owner, repo } = await params;

    const path = req.nextUrl.searchParams.get("path") ?? "";
    const branch = req.nextUrl.searchParams.get("branch") ?? undefined;

    const octokit = await createGithubClient(user.id);
    const response = await octokit.rest.repos.getContent({ owner, repo, path, ref: branch });

    const data = response.data;
    if (!Array.isArray(data)) {
      return NextResponse.json({ error: "Path is not a directory" }, { status: 400 });
    }

    const children = data
      .map((entry) => ({
        name: entry.name,
        path: entry.path,
        type: entry.type === "dir" ? ("folder" as const) : ("file" as const),
        sha: entry.sha,
        size: entry.type === "file" ? entry.size : undefined,
      }))
      .sort((a, b) => {
        if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
        return a.name.localeCompare(b.name);
      });

    return NextResponse.json({ children }, { status: 200 });
  } catch (err: any) {
    if (err.status === 404) return NextResponse.json({ error: "Folder not found" }, { status: 404 });
    if (err instanceof GithubApiError) return NextResponse.json({ error: err.message }, { status: err.status ?? 502 });
    console.error("Error fetching folder children:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
