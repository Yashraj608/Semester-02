import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createGithubClient } from "@/lib/github/client";
import { findExistingFileNames, findConflicts } from "@/lib/github/duplicate-check";

interface RouteParams {
  params: Promise<{ owner: string; repo: string }>;
}

export async function POST(req: NextRequest, { params }: RouteParams) {
  const user = await requireUser();
  const { owner, repo } = await params;
  const { fileDestinations, branch } = (await req.json()) as {
    fileDestinations: Record<string, string>;
    branch: string;
  };

  const octokit = await createGithubClient(user.id);

  const byFolder = new Map<string, string[]>();
  for (const [fileName, folder] of Object.entries(fileDestinations)) {
    if (!byFolder.has(folder)) byFolder.set(folder, []);
    byFolder.get(folder)!.push(fileName);
  }

  const allConflicts = [];
  for (const [folder, fileNames] of byFolder) {
    const existingNames = await findExistingFileNames(octokit, owner, repo, folder, branch);
    allConflicts.push(...findConflicts(fileNames, existingNames));
  }

  return NextResponse.json({ conflicts: allConflicts }, { status: 200 });
}
