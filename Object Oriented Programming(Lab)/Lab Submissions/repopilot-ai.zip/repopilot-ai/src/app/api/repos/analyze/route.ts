import { NextRequest, NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createGithubClient } from "@/lib/github/client";
import { getRepositoryMetadata } from "@/lib/github/repository";
import { fetchFullTree, buildNestedTree } from "@/lib/github/tree";
import { parseGithubRepoUrl } from "@/lib/github/url-parser";
import { analyzeRepoSchema } from "@/lib/validation/schemas";
import { RepoNotFoundError, InsufficientPermissionsError, InvalidRepoUrlError, GithubApiError } from "@/lib/github/errors";

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();

    const body = await req.json();
    const parsed = analyzeRepoSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid request", details: parsed.error.flatten() }, { status: 400 });
    }

    const { owner, repo } = parseGithubRepoUrl(parsed.data.repoUrl);
    const octokit = await createGithubClient(user.id);

    const metadata = await getRepositoryMetadata(octokit, owner, repo, "pull");
    const branch = parsed.data.branch ?? metadata.defaultBranch;

    const { entries, truncated } = await fetchFullTree(octokit, owner, repo, branch);
    const tree = buildNestedTree(entries);

    return NextResponse.json(
      {
        repository: metadata,
        branch,
        tree,
        stats: {
          totalFiles: entries.filter((e) => e.type === "blob").length,
          totalFolders: entries.filter((e) => e.type === "tree").length,
          usedFallbackWalk: truncated,
        },
      },
      { status: 200 }
    );
  } catch (err) {
    return handleAnalyzerError(err);
  }
}

function handleAnalyzerError(err: unknown): NextResponse {
  if (err instanceof InvalidRepoUrlError) return NextResponse.json({ error: err.message }, { status: 400 });
  if (err instanceof RepoNotFoundError) return NextResponse.json({ error: err.message }, { status: 404 });
  if (err instanceof InsufficientPermissionsError) return NextResponse.json({ error: err.message }, { status: 403 });
  if (err instanceof GithubApiError) return NextResponse.json({ error: err.message }, { status: err.status ?? 502 });

  console.error("Unexpected error in repo analyzer:", err);
  return NextResponse.json({ error: "Internal server error" }, { status: 500 });
}
