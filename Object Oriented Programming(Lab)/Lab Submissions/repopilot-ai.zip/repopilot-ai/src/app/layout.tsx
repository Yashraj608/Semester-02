import { SessionProvider } from "next-auth/react";
import { auth } from "@/lib/auth/auth";
import "./globals.css";

export const metadata = {
  title: "RepoPilot AI",
  description: "Analyze GitHub repos, browse their structure, and commit new files with AI-assisted placement.",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();

  return (
    <html lang="en" className="dark">
      <body className="bg-explorer-bg text-explorer-text min-h-screen">
        <SessionProvider session={session}>{children}</SessionProvider>
      </body>
    </html>
  );
}
