"use client";

import { signIn } from "next-auth/react";
import { Github } from "lucide-react";

export function LoginButton() {
  return (
    <button
      onClick={() => signIn("github", { callbackUrl: "/repos" })}
      className="flex items-center gap-2 bg-explorer-accent text-white px-4 py-2 rounded-sm text-[14px] hover:opacity-90"
    >
      <Github size={16} />
      Sign in with GitHub
    </button>
  );
}
