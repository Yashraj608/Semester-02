"use client";

import { signOut } from "next-auth/react";

export function LogoutButton() {
  return (
    <button onClick={() => signOut({ callbackUrl: "/" })} className="text-[13px] text-explorer-muted hover:text-explorer-text">
      Sign out
    </button>
  );
}
