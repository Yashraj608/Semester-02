import Image from "next/image";
import { auth } from "@/lib/auth/auth";
import { LogoutButton } from "@/components/auth/logout-button";

export async function Navbar() {
  const session = await auth();

  return (
    <nav className="flex items-center justify-between px-4 py-2.5 border-b border-explorer-border bg-explorer-sidebar">
      <span className="text-[14px] font-medium text-explorer-text">RepoPilot AI</span>
      {session?.user && (
        <div className="flex items-center gap-3">
          {session.user.image && (
            <Image src={session.user.image} alt={session.user.name ?? "User"} width={24} height={24} className="rounded-full" />
          )}
          <span className="text-[13px] text-explorer-muted">{session.user.name}</span>
          <LogoutButton />
        </div>
      )}
    </nav>
  );
}
