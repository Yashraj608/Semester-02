"use client";

import { useEffect, useState } from "react";
import { RepoExplorer } from "@/components/tree/repo-explorer";
import { CommitPanel } from "@/components/upload/commit-panel";
import type { ClientTreeNode } from "@/lib/tree/types";

interface RepoExplorerWithCommitProps {
  owner: string;
  repo: string;
  branch: string;
}

export function RepoExplorerWithCommit({ owner, repo, branch }: RepoExplorerWithCommitProps) {
  const [rootChildren, setRootChildren] = useState<ClientTreeNode[] | null>(null);

  useEffect(() => {
    let cancelled = false;

    fetch(`/api/repos/${owner}/${repo}/tree/children?path=&branch=${encodeURIComponent(branch)}`)
      .then((res) => res.json())
      .then((data) => {
        if (!cancelled) setRootChildren(data.children ?? []);
      })
      .catch((err) => {
        console.error("Failed to load root folder:", err);
        if (!cancelled) setRootChildren([]);
      });

    return () => {
      cancelled = true;
    };
  }, [owner, repo, branch]);

  return (
    <div className="flex flex-col md:flex-row gap-4 items-start">
      <RepoExplorer owner={owner} repo={repo} branch={branch} initialChildren={rootChildren} />
      <CommitPanel owner={owner} repo={repo} branch={branch} />
    </div>
  );
}
