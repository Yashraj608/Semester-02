"use client";

import { ChevronRight, Home } from "lucide-react";
import { cn } from "@/lib/utils";

interface BreadcrumbProps {
  path: string | null;
  onNavigate: (path: string) => void;
}

export function Breadcrumb({ path, onNavigate }: BreadcrumbProps) {
  const segments = path ? path.split("/") : [];

  return (
    <div className="flex items-center gap-1 px-3 py-1.5 text-[12px] text-explorer-muted border-b border-explorer-border overflow-x-auto whitespace-nowrap" aria-label="Breadcrumb">
      <button onClick={() => onNavigate("")} className={cn("hover:text-explorer-text flex items-center gap-1", !path && "text-explorer-text")}>
        <Home size={12} />
      </button>

      {segments.map((segment, i) => {
        const segmentPath = segments.slice(0, i + 1).join("/");
        const isLast = i === segments.length - 1;
        return (
          <span key={segmentPath} className="flex items-center gap-1">
            <ChevronRight size={11} className="text-explorer-muted/60" />
            <button onClick={() => onNavigate(segmentPath)} className={cn("hover:text-explorer-text hover:underline", isLast && "text-explorer-text")}>
              {segment}
            </button>
          </span>
        );
      })}
    </div>
  );
}
