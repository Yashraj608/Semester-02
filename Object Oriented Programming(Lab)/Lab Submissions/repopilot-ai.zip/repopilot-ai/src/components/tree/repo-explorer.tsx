"use client";

import { useState } from "react";
import { useRepoExplorer } from "@/hooks/use-repo-explorer";
import { TreeSearch } from "./tree-search";
import { Breadcrumb } from "./breadcrumb";
import { VirtualTree } from "./virtual-tree";
import { SkeletonRows } from "./skeleton-rows";
import type { ClientTreeNode } from "@/lib/tree/types";

interface RepoExplorerProps {
  owner: string;
  repo: string;
  branch: string;
  initialChildren: ClientTreeNode[] | null;
  onSelectFolder?: (path: string) => void;
}

export function RepoExplorer({ owner, repo, branch, initialChildren, onSelectFolder }: RepoExplorerProps) {
  const [breadcrumbPath, setBreadcrumbPath] = useState<string | null>(null);

  const { rows, selectedPath, setSelectedPath, toggleFolder, runSearch, isSearching } = useRepoExplorer({
    owner,
    repo,
    branch,
    initialChildren: initialChildren ?? [],
  });

  return (
    <div className="flex flex-col h-[640px] w-full max-w-md bg-explorer-sidebar border border-explorer-border rounded-md overflow-hidden font-ui">
      <div className="px-3 py-2 border-b border-explorer-border">
        <span className="text-[11px] uppercase tracking-wide text-explorer-muted font-medium">{owner}/{repo}</span>
      </div>

      <TreeSearch onSearch={runSearch} isSearching={isSearching} />
      <Breadcrumb path={breadcrumbPath} onNavigate={setBreadcrumbPath} />

      <div className="flex-1 min-h-0">
        {initialChildren === null ? (
          <SkeletonRows />
        ) : (
          <VirtualTree
            rows={rows}
            selectedPath={selectedPath}
            onSelect={(path) => {
              setSelectedPath(path);
              setBreadcrumbPath(path);
              onSelectFolder?.(path);
            }}
            onToggle={(row) => toggleFolder(row.node)}
          />
        )}
      </div>
    </div>
  );
}
