export function SkeletonRows({ count = 12 }: { count?: number }) {
  return (
    <div className="px-2 py-1 space-y-1" aria-label="Loading repository tree" role="status">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="flex items-center gap-2 h-6" style={{ paddingLeft: (i % 3) * 12 }}>
          <div className="h-3.5 w-3.5 rounded-sm bg-explorer-hover animate-pulse" />
          <div className="h-3 rounded-sm bg-explorer-hover animate-pulse" style={{ width: `${40 + ((i * 37) % 100)}px` }} />
        </div>
      ))}
    </div>
  );
}
