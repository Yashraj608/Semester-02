"use client";

import { ChevronRight, ChevronDown, Loader2 } from "lucide-react";
import { getFileIcon, getFolderIcon } from "@/lib/tree/icons";
import type { FlattenedRow } from "@/lib/tree/types";
import { cn } from "@/lib/utils";

interface TreeRowProps {
  row: FlattenedRow;
  isSelected: boolean;
  onSelect: () => void;
  onToggle: () => void;
  style: React.CSSProperties;
}

const INDENT_PX = 16;
const ROW_HEIGHT = 24;

export function TreeRow({ row, isSelected, onSelect, onToggle, style }: TreeRowProps) {
  const { node, depth, isExpanded, isLoading, isMatch } = row;
  const isFolder = node.type === "folder";
  const { Icon, colorClass } = isFolder ? getFolderIcon(isExpanded) : getFileIcon(node.name);

  return (
    <div
      role="treeitem"
      aria-expanded={isFolder ? isExpanded : undefined}
      aria-selected={isSelected}
      tabIndex={0}
      onClick={() => {
        onSelect();
        if (isFolder) onToggle();
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect();
          if (isFolder) onToggle();
        }
      }}
      style={{ ...style, paddingLeft: depth * INDENT_PX + 8, height: ROW_HEIGHT }}
      className={cn(
        "flex items-center gap-1.5 text-[13px] cursor-pointer select-none rounded-sm",
        "text-explorer-text hover:bg-explorer-hover",
        isSelected && "bg-explorer-selected",
        isMatch && "ring-1 ring-inset ring-explorer-accent/60"
      )}
    >
      {isFolder ? (
        <span className="flex h-4 w-4 items-center justify-center shrink-0 text-explorer-muted">
          {isLoading ? <Loader2 size={12} className="animate-spin" /> : isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
        </span>
      ) : (
        <span className="w-4 shrink-0" />
      )}
      <Icon className={cn("shrink-0", colorClass)} size={16} />
      <span className="truncate">{node.name}</span>
    </div>
  );
}

export { ROW_HEIGHT };
