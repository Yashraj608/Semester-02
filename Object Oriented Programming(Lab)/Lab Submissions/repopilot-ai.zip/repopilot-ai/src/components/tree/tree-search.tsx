"use client";

import { useState, useEffect, useRef } from "react";
import { Search, X, Loader2 } from "lucide-react";

interface TreeSearchProps {
  onSearch: (query: string) => void;
  isSearching: boolean;
}

export function TreeSearch({ onSearch, isSearching }: TreeSearchProps) {
  const [value, setValue] = useState("");
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => onSearch(value), 300);
    return () => clearTimeout(debounceRef.current);
  }, [value, onSearch]);

  return (
    <div className="relative px-2 py-2 border-b border-explorer-border">
      <Search size={13} className="absolute left-4 top-1/2 -translate-y-1/2 text-explorer-muted pointer-events-none" />
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Search files and folders"
        aria-label="Search files and folders"
        className="w-full bg-explorer-bg border border-explorer-border rounded-sm py-1 pl-7 pr-7 text-[13px] text-explorer-text placeholder:text-explorer-muted focus:outline-none focus:border-explorer-accent"
      />
      {isSearching ? (
        <Loader2 size={13} className="absolute right-4 top-1/2 -translate-y-1/2 animate-spin text-explorer-muted" />
      ) : (
        value && (
          <button onClick={() => setValue("")} aria-label="Clear search" className="absolute right-4 top-1/2 -translate-y-1/2 text-explorer-muted hover:text-explorer-text">
            <X size={13} />
          </button>
        )
      )}
    </div>
  );
}
