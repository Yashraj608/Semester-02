"use client";

import { useState, useMemo } from "react";
import { TreeRow, ROW_HEIGHT } from "./tree-row";
import type { FlattenedRow } from "@/lib/tree/types";

interface VirtualTreeProps {
  rows: FlattenedRow[];
  selectedPath: string | null;
  onSelect: (path: string) => void;
  onToggle: (row: FlattenedRow) => void;
}

const OVERSCAN = 8;

export function VirtualTree({ rows, selectedPath, onSelect, onToggle }: VirtualTreeProps) {
  const [scrollTop, setScrollTop] = useState(0);
  const [viewportHeight, setViewportHeight] = useState(600);

  const totalHeight = rows.length * ROW_HEIGHT;

  const { startIndex, endIndex } = useMemo(() => {
    const start = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - OVERSCAN);
    const visibleCount = Math.ceil(viewportHeight / ROW_HEIGHT) + OVERSCAN * 2;
    const end = Math.min(rows.length, start + visibleCount);
    return { startIndex: start, endIndex: end };
  }, [scrollTop, viewportHeight, rows.length]);

  const visibleRows = rows.slice(startIndex, endIndex);

  return (
    <div
      onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
      className="relative overflow-y-auto h-full"
      role="tree"
      aria-label="Repository file tree"
      ref={(el) => {
        if (el && el.clientHeight !== viewportHeight) setViewportHeight(el.clientHeight);
      }}
    >
      <div style={{ height: totalHeight, position: "relative" }}>
        {visibleRows.map((row, i) => (
          <TreeRow
            key={row.node.path}
            row={row}
            isSelected={selectedPath === row.node.path}
            onSelect={() => onSelect(row.node.path)}
            onToggle={() => onToggle(row)}
            style={{ position: "absolute", top: (startIndex + i) * ROW_HEIGHT, left: 0, right: 0 }}
          />
        ))}
      </div>
    </div>
  );
}
