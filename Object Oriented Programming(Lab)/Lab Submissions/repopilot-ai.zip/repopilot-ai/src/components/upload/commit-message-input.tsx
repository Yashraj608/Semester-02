"use client";

import { Sparkles, Loader2 } from "lucide-react";
import type { ValidatedFile } from "@/lib/upload/validate-files";
import { useGenerateCommitMessage } from "@/hooks/use-generate-commit-message";

interface CommitMessageInputProps {
  owner: string;
  repo: string;
  targetFolder: string;
  files: ValidatedFile[];
  value: string;
  onChange: (value: string) => void;
}

export function CommitMessageInput({ owner, repo, targetFolder, files, value, onChange }: CommitMessageInputProps) {
  const { generate, isGenerating } = useGenerateCommitMessage(owner, repo);

  async function handleGenerate() {
    if (files.length === 0) return;

    const summaries = await Promise.all(
      files.map(async (f) => {
        const isText = f.file.type.startsWith("text/") || /\.(md|txt|json|ya?ml|ts|tsx|js|jsx|css|html|py|csv)$/i.test(f.displayName);
        const textPreview = isText ? (await f.file.text()).slice(0, 500) : undefined;
        return { name: f.displayName, path: targetFolder ? `${targetFolder}/${f.displayName}` : f.displayName, sizeBytes: f.file.size, textPreview };
      })
    );

    const { message } = await generate(summaries, targetFolder);
    onChange(message);
  }

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="text-[12px] text-explorer-muted">Commit message</label>
        <button onClick={handleGenerate} disabled={files.length === 0 || isGenerating} className="flex items-center gap-1 text-[11px] text-explorer-accent hover:opacity-80 disabled:opacity-40">
          {isGenerating ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
          Generate with AI
        </button>
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Describe what changed…"
        rows={2}
        className="w-full bg-explorer-bg border border-explorer-border rounded-sm text-[13px] p-2 text-explorer-text"
      />
    </div>
  );
}
