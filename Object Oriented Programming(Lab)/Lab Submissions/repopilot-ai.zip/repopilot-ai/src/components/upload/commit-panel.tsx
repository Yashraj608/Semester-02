"use client";

import { useState } from "react";
import { FileDropzone } from "./file-dropzone";
import { FileDestinationList } from "./file-destination-list";
import { CommitMessageInput } from "./commit-message-input";
import { ConflictDialog, type Conflict, type ResolutionMap } from "./conflict-dialog";
import { UploadProgressList } from "./upload-progress-list";
import { useCommitUpload } from "@/hooks/use-commit-upload";
import type { ValidatedFile } from "@/lib/upload/validate-files";

interface CommitPanelProps {
  owner: string;
  repo: string;
  branch: string;
}

export function CommitPanel({ owner, repo, branch }: CommitPanelProps) {
  const [files, setFiles] = useState<ValidatedFile[]>([]);
  const [confirmedDestinations, setConfirmedDestinations] = useState<Record<string, string>>({});
  const [commitMessage, setCommitMessage] = useState("");
  const [createNewBranch, setCreateNewBranch] = useState(false);
  const [newBranchName, setNewBranchName] = useState("");
  const [conflicts, setConflicts] = useState<Conflict[] | null>(null);

  const { phase, uploadPercent, fileProgress, stage, result, error, rolledBack, commit } = useCommitUpload();

  const allDestinationsConfirmed = files.length > 0 && files.every((f) => confirmedDestinations[f.displayName] !== undefined);

  async function startCommit(resolutions: ResolutionMap = {}) {
    await commit({
      owner,
      repo,
      branch,
      newBranchName: createNewBranch ? newBranchName : null,
      commitMessage: commitMessage || `Upload ${files.length} file(s) via RepoPilot AI`,
      files: files.map((f) => f.file),
      fileDestinations: confirmedDestinations,
      resolutions,
    });
  }

  async function handleSubmit() {
    const res = await fetch(`/api/repos/${owner}/${repo}/uploads/check-conflicts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileDestinations: confirmedDestinations, branch }),
    });
    const { conflicts: found } = (await res.json()) as { conflicts: Conflict[] };

    if (found.length > 0) setConflicts(found);
    else startCommit();
  }

  return (
    <div className="space-y-3 p-3 border border-explorer-border rounded-md bg-explorer-sidebar w-full max-w-md">
      <h2 className="text-[13px] font-medium text-explorer-text">Upload files</h2>

      <FileDropzone files={files} onFilesChange={setFiles} />

      <FileDestinationList
        owner={owner}
        repo={repo}
        branch={branch}
        files={files}
        confirmedDestinations={confirmedDestinations}
        onConfirmDestination={(fileName, folder) => setConfirmedDestinations((prev) => ({ ...prev, [fileName]: folder }))}
      />

      <CommitMessageInput owner={owner} repo={repo} targetFolder="" files={files} value={commitMessage} onChange={setCommitMessage} />

      <label className="flex items-center gap-2 text-[12px] text-explorer-muted">
        <input type="checkbox" checked={createNewBranch} onChange={(e) => setCreateNewBranch(e.target.checked)} />
        Create a new branch
      </label>
      {createNewBranch && (
        <input
          value={newBranchName}
          onChange={(e) => setNewBranchName(e.target.value)}
          placeholder="feature/upload-assets"
          className="w-full bg-explorer-bg border border-explorer-border rounded-sm text-[13px] p-2 text-explorer-text"
        />
      )}

      <button
        onClick={handleSubmit}
        disabled={!allDestinationsConfirmed || phase === "sending" || phase === "committing"}
        className="w-full bg-explorer-accent text-white text-[13px] rounded-sm py-2 disabled:opacity-50"
      >
        Upload and commit
      </button>

      <UploadProgressList phase={phase} uploadPercent={uploadPercent} stage={stage} fileProgress={fileProgress} error={error} rolledBack={rolledBack} />

      {phase === "success" && result && (
        <p className="text-[13px] text-green-500">
          Committed {result.filesCommitted} file(s) —{" "}
          <a href={result.commitUrl} target="_blank" rel="noreferrer" className="underline">view commit</a>
        </p>
      )}

      {conflicts && (
        <ConflictDialog conflicts={conflicts} onCancel={() => setConflicts(null)} onResolve={(resolutions) => { setConflicts(null); startCommit(resolutions); }} />
      )}
    </div>
  );
}
