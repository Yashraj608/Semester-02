"use client";

import { useState } from "react";

export interface Conflict {
  fileName: string;
  suggestedName: string;
}

export type ConflictAction = "overwrite" | "rename" | "skip";
export type ResolutionMap = Record<string, { action: ConflictAction; finalName?: string }>;

interface ConflictDialogProps {
  conflicts: Conflict[];
  onResolve: (resolutions: ResolutionMap) => void;
  onCancel: () => void;
}

export function ConflictDialog({ conflicts, onResolve, onCancel }: ConflictDialogProps) {
  const [choices, setChoices] = useState<ResolutionMap>(
    Object.fromEntries(conflicts.map((c) => [c.fileName, { action: "rename" as const, finalName: c.suggestedName }]))
  );

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-explorer-sidebar border border-explorer-border rounded-md p-4 w-full max-w-sm space-y-3">
        <h3 className="text-[14px] font-medium text-explorer-text">
          {conflicts.length} file{conflicts.length > 1 ? "s" : ""} already exist in this folder
        </h3>

        <div className="space-y-3 max-h-72 overflow-y-auto">
          {conflicts.map((c) => (
            <div key={c.fileName} className="text-[13px] space-y-1">
              <p className="text-explorer-text truncate">{c.fileName}</p>
              <div className="flex gap-3 text-[12px] text-explorer-muted">
                {(["overwrite", "rename", "skip"] as const).map((action) => (
                  <label key={action} className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name={c.fileName}
                      checked={choices[c.fileName]?.action === action}
                      onChange={() => setChoices((prev) => ({ ...prev, [c.fileName]: { action, finalName: action === "rename" ? c.suggestedName : undefined } }))}
                    />
                    {action === "overwrite" ? "Overwrite" : action === "rename" ? "Keep both" : "Skip"}
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <button onClick={onCancel} className="text-[13px] px-3 py-1.5 text-explorer-muted hover:text-explorer-text">Cancel</button>
          <button onClick={() => onResolve(choices)} className="text-[13px] px-3 py-1.5 bg-explorer-accent text-white rounded-sm hover:opacity-90">Continue</button>
        </div>
      </div>
    </div>
  );
}
