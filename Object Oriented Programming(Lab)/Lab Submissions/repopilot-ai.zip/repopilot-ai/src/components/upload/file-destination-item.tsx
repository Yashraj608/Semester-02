"use client";

import { useState } from "react";
import { Check, Sparkles, Pencil, FolderOpen } from "lucide-react";
import type { DestinationSuggestion } from "@/types/ai-suggestions";
import { cn } from "@/lib/utils";

interface FileDestinationItemProps {
  fileName: string;
  suggestion: DestinationSuggestion | undefined;
  isLoadingSuggestion: boolean;
  confirmedFolder: string | null;
  onConfirm: (folder: string) => void;
}

const CONFIDENCE_LABEL: Record<string, string> = { high: "Confident", medium: "Likely", low: "Uncertain" };

export function FileDestinationItem({ fileName, suggestion, isLoadingSuggestion, confirmedFolder, onConfirm }: FileDestinationItemProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [customFolder, setCustomFolder] = useState(suggestion?.suggestedFolder ?? "");

  const isConfirmed = confirmedFolder !== null;
  const displayFolder = confirmedFolder ?? suggestion?.suggestedFolder ?? "";

  return (
    <div className="border border-explorer-border rounded-sm p-2 space-y-1.5">
      <div className="flex items-center justify-between text-[13px]">
        <span className="text-explorer-text truncate">{fileName}</span>
        {isConfirmed && <Check size={14} className="text-green-500 shrink-0" />}
      </div>

      {isLoadingSuggestion ? (
        <p className="text-[11px] text-explorer-muted">Analyzing file…</p>
      ) : isEditing ? (
        <div className="flex items-center gap-1.5">
          <FolderOpen size={12} className="text-explorer-muted shrink-0" />
          <input
            value={customFolder}
            onChange={(e) => setCustomFolder(e.target.value)}
            placeholder="repository root"
            className="flex-1 bg-explorer-bg border border-explorer-border rounded-sm text-[12px] px-1.5 py-0.5 text-explorer-text"
          />
          <button onClick={() => { onConfirm(customFolder.trim()); setIsEditing(false); }} className="text-[11px] text-explorer-accent">Set</button>
        </div>
      ) : (
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-[12px] text-explorer-text min-w-0">
            <Sparkles size={11} className={cn("shrink-0", suggestion ? "text-explorer-accent" : "text-explorer-muted")} />
            <span className="truncate">/{displayFolder || "repository root"}</span>
            {suggestion && !isConfirmed && <span className="text-[10px] text-explorer-muted shrink-0">{CONFIDENCE_LABEL[suggestion.confidence]}</span>}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {!isConfirmed && suggestion && (
              <button onClick={() => onConfirm(suggestion.suggestedFolder)} className="text-[11px] text-green-500 hover:underline">Accept</button>
            )}
            <button onClick={() => { setCustomFolder(displayFolder); setIsEditing(true); }} className="text-[11px] text-explorer-muted hover:text-explorer-text flex items-center gap-0.5">
              <Pencil size={10} /> {isConfirmed ? "Change" : "Choose"}
            </button>
          </div>
        </div>
      )}

      {suggestion && !isEditing && <p className="text-[11px] text-explorer-muted italic">{suggestion.reasoning}</p>}
    </div>
  );
}
