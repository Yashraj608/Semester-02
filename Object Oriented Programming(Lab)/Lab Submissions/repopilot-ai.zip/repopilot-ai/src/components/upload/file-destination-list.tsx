"use client";

import { useEffect } from "react";
import { useSuggestDestinations } from "@/hooks/use-suggest-destinations";
import { FileDestinationItem } from "./file-destination-item";
import type { ValidatedFile } from "@/lib/upload/validate-files";

interface FileDestinationListProps {
  owner: string;
  repo: string;
  branch: string;
  files: ValidatedFile[];
  confirmedDestinations: Record<string, string>;
  onConfirmDestination: (fileName: string, folder: string) => void;
}

export function FileDestinationList({ owner, repo, branch, files, confirmedDestinations, onConfirmDestination }: FileDestinationListProps) {
  const { suggestions, fetchSuggestions, isLoading } = useSuggestDestinations(owner, repo, branch);

  useEffect(() => {
    if (files.length > 0) fetchSuggestions(files);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [files.map((f) => f.displayName).join(",")]);

  if (files.length === 0) return null;

  const allConfirmed = files.every((f) => confirmedDestinations[f.displayName] !== undefined);

  return (
    <div className="space-y-2">
      <p className="text-[12px] text-explorer-muted">AI-suggested destinations — review and confirm each one before committing</p>
      {files.map((f) => (
        <FileDestinationItem
          key={f.displayName}
          fileName={f.displayName}
          suggestion={suggestions[f.displayName]}
          isLoadingSuggestion={isLoading && !suggestions[f.displayName]}
          confirmedFolder={confirmedDestinations[f.displayName] ?? null}
          onConfirm={(folder) => onConfirmDestination(f.displayName, folder)}
        />
      ))}
      {!allConfirmed && <p className="text-[11px] text-explorer-accent">Confirm a destination for every file to enable committing.</p>}
    </div>
  );
}
