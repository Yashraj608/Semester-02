"use client";

import { useCallback, useState } from "react";
import { UploadCloud, X, FileWarning } from "lucide-react";
import { validateAndDedupeBatch, type ValidatedFile } from "@/lib/upload/validate-files";
import { cn } from "@/lib/utils";

interface FileDropzoneProps {
  files: ValidatedFile[];
  onFilesChange: (files: ValidatedFile[]) => void;
}

export function FileDropzone({ files, onFilesChange }: FileDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [rejections, setRejections] = useState<{ name: string; reason: string }[]>([]);

  const addFiles = useCallback(
    (incoming: File[]) => {
      const { accepted, rejected } = validateAndDedupeBatch([...files.map((f) => f.file), ...incoming]);
      onFilesChange(accepted);
      setRejections(rejected);
    },
    [files, onFilesChange]
  );

  return (
    <div className="space-y-2">
      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => { e.preventDefault(); setIsDragging(false); addFiles(Array.from(e.dataTransfer.files)); }}
        className={cn(
          "border-2 border-dashed rounded-md p-6 text-center transition-colors cursor-pointer border-explorer-border text-explorer-muted",
          isDragging && "border-explorer-accent bg-explorer-accent/5"
        )}
        onClick={() => document.getElementById("file-input")?.click()}
      >
        <UploadCloud className="mx-auto mb-2" size={22} />
        <p className="text-[13px]">Drag files here, or click to browse</p>
        <p className="text-[11px] mt-1">Images, PDFs, ZIP archives, and text files — up to 50MB each</p>
        <input
          id="file-input"
          type="file"
          multiple
          accept="image/*,application/pdf,.zip,text/*,.md,.json,.yml,.yaml,.ts,.tsx,.js,.jsx,.css,.html,.py,.csv"
          className="hidden"
          onChange={(e) => e.target.files && addFiles(Array.from(e.target.files))}
        />
      </div>

      {rejections.length > 0 && (
        <div className="text-[12px] text-explorer-accent flex flex-col gap-1">
          {rejections.map((r) => (
            <span key={r.name} className="flex items-center gap-1"><FileWarning size={12} /> {r.reason}</span>
          ))}
        </div>
      )}

      {files.length > 0 && (
        <ul className="space-y-1">
          {files.map((f) => (
            <li key={f.displayName} className="flex items-center justify-between text-[13px] bg-explorer-bg border border-explorer-border rounded-sm px-2 py-1">
              <span className="truncate">{f.displayName}</span>
              <button onClick={() => onFilesChange(files.filter((x) => x.displayName !== f.displayName))} aria-label={`Remove ${f.displayName}`} className="text-explorer-muted hover:text-explorer-text">
                <X size={13} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
