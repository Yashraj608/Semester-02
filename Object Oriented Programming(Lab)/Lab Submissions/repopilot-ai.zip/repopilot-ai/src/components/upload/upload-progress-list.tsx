"use client";

import { Check, Loader2, X, Clock } from "lucide-react";
import type { FileProgressMap, CommitPhase } from "@/hooks/use-commit-upload";

const STAGE_LABELS: Record<string, string> = {
  "resolving-branch": "Resolving branch",
  "creating-branch": "Creating new branch",
  "creating-tree": "Building commit tree",
  "creating-commit": "Creating commit",
  "pushing": "Pushing changes",
};

interface UploadProgressListProps {
  phase: CommitPhase;
  uploadPercent: number;
  stage: string | null;
  fileProgress: FileProgressMap;
  error?: string | null;
  rolledBack?: boolean;
}

export function UploadProgressList({ phase, uploadPercent, stage, fileProgress, error, rolledBack }: UploadProgressListProps) {
  if (phase === "idle") return null;

  return (
    <div className="space-y-3 text-[13px]">
      {phase === "sending" && (
        <div>
          <p className="text-explorer-muted mb-1">Sending files to server — {uploadPercent}%</p>
          <div className="h-1.5 bg-explorer-bg rounded-full overflow-hidden">
            <div className="h-full bg-explorer-accent transition-all" style={{ width: `${uploadPercent}%` }} />
          </div>
        </div>
      )}

      {(phase === "committing" || phase === "success") && stage && (
        <p className="text-explorer-muted">{STAGE_LABELS[stage] ?? stage}…</p>
      )}

      <ul className="space-y-1">
        {Object.entries(fileProgress).map(([fileName, status]) => (
          <li key={fileName} className="flex items-center gap-2 text-explorer-text">
            {status === "done" && <Check size={14} className="text-green-500" />}
            {status === "skipped" && <Clock size={14} className="text-explorer-muted" />}
            {status === "error" && <X size={14} className="text-red-500" />}
            {(status === "encoding" || status === "uploading-blob") && <Loader2 size={14} className="animate-spin text-explorer-accent" />}
            <span className="truncate">{fileName}</span>
            <span className="text-[11px] text-explorer-muted ml-auto capitalize">{status.replace("-", " ")}</span>
          </li>
        ))}
      </ul>

      {phase === "error" && error && (
        <div className="text-[13px] text-red-500 space-y-1">
          <p>{error}</p>
          {rolledBack && <p className="text-[11px] text-explorer-muted">The new branch was removed automatically — nothing was left in a partial state.</p>}
        </div>
      )}
    </div>
  );
}
