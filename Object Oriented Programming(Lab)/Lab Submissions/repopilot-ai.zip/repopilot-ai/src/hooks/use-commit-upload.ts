"use client";

import { useState, useCallback, useRef } from "react";

export type FileStatus = "pending" | "encoding" | "uploading-blob" | "done" | "skipped" | "error";
export type CommitPhase = "idle" | "sending" | "committing" | "success" | "error";

export interface FileProgressMap {
  [fileName: string]: FileStatus;
}

interface CommitParams {
  owner: string;
  repo: string;
  branch: string;
  newBranchName?: string | null;
  commitMessage: string;
  files: File[];
  fileDestinations: Record<string, string>;
  resolutions: Record<string, { action: "overwrite" | "rename" | "skip"; finalName?: string }>;
}

export function useCommitUpload() {
  const [phase, setPhase] = useState<CommitPhase>("idle");
  const [uploadPercent, setUploadPercent] = useState(0);
  const [fileProgress, setFileProgress] = useState<FileProgressMap>({});
  const [stage, setStage] = useState<string | null>(null);
  const [result, setResult] = useState<{ commitUrl: string; filesCommitted: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [rolledBack, setRolledBack] = useState(false);
  const xhrRef = useRef<XMLHttpRequest | null>(null);

  const commit = useCallback((params: CommitParams) => {
    setPhase("sending");
    setUploadPercent(0);
    setFileProgress({});
    setStage(null);
    setResult(null);
    setError(null);
    setRolledBack(false);

    return new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhrRef.current = xhr;
      xhr.open("POST", `/api/repos/${params.owner}/${params.repo}/commit`);

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) setUploadPercent(Math.round((e.loaded / e.total) * 100));
      };

      let lastReadIndex = 0;
      xhr.onprogress = () => {
        setPhase("committing");
        const newChunk = xhr.responseText.slice(lastReadIndex);
        lastReadIndex = xhr.responseText.length;

        for (const line of newChunk.split("\n").filter(Boolean)) {
          try {
            handleEvent(JSON.parse(line));
          } catch {}
        }
      };

      function handleEvent(event: any) {
        if (event.type === "stage") setStage(event.stage);
        else if (event.type === "file-progress") setFileProgress((prev) => ({ ...prev, [event.fileName]: event.status }));
        else if (event.type === "done") {
          setPhase("success");
          setResult({ commitUrl: event.commitUrl, filesCommitted: event.filesCommitted });
          resolve();
        } else if (event.type === "error") {
          setPhase("error");
          setError(event.message);
          setRolledBack(!!event.rolledBack);
          reject(new Error(event.message));
        }
      }

      xhr.onerror = () => {
        setPhase("error");
        setError("Network error while committing");
        reject(new Error("Network error"));
      };

      const formData = new FormData();
      formData.append("branch", params.branch);
      if (params.newBranchName) formData.append("newBranchName", params.newBranchName);
      formData.append("commitMessage", params.commitMessage);
      formData.append("fileDestinations", JSON.stringify(params.fileDestinations));
      formData.append("resolutions", JSON.stringify(params.resolutions));
      for (const file of params.files) formData.append("files", file, file.name);

      xhr.send(formData);
    });
  }, []);

  const cancel = useCallback(() => {
    xhrRef.current?.abort();
    setPhase("idle");
  }, []);

  return { phase, uploadPercent, fileProgress, stage, result, error, rolledBack, commit, cancel };
}
