"use client";

import { useState, useCallback } from "react";

interface FileSummaryInput {
  name: string;
  path: string;
  sizeBytes: number;
  textPreview?: string;
}

export function useGenerateCommitMessage(owner: string, repo: string) {
  const [isGenerating, setIsGenerating] = useState(false);

  const generate = useCallback(
    async (files: FileSummaryInput[], targetFolder: string): Promise<{ message: string; aiGenerated: boolean }> => {
      setIsGenerating(true);
      try {
        const res = await fetch(`/api/repos/${owner}/${repo}/commit-message`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ files, targetFolder }),
        });
        if (!res.ok) throw new Error("Failed to generate commit message");
        return await res.json();
      } finally {
        setIsGenerating(false);
      }
    },
    [owner, repo]
  );

  return { generate, isGenerating };
}
