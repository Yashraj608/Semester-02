"use client";

import { useState, useCallback, useMemo, useRef } from "react";
import type { ClientTreeNode } from "@/lib/tree/types";
import { flattenTree, findNodeByPath } from "@/lib/tree/flatten";

interface UseRepoExplorerOptions {
  owner: string;
  repo: string;
  branch: string;
  initialChildren: ClientTreeNode[];
}

export function useRepoExplorer({ owner, repo, branch, initialChildren }: UseRepoExplorerOptions) {
  const [rootNodes, setRootNodes] = useState<ClientTreeNode[]>(initialChildren);
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set());
  const [loadingPaths, setLoadingPaths] = useState<Set<string>>(new Set());
  const [selectedPath, setSelectedPath] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [matchedPaths, setMatchedPaths] = useState<Set<string> | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const searchAbortRef = useRef<AbortController | null>(null);

  const fetchChildren = useCallback(
    async (path: string) => {
      setLoadingPaths((prev) => new Set(prev).add(path));
      try {
        const res = await fetch(
          `/api/repos/${owner}/${repo}/tree/children?path=${encodeURIComponent(path)}&branch=${encodeURIComponent(branch)}`
        );
        if (!res.ok) throw new Error("Failed to load folder");
        const { children } = (await res.json()) as { children: ClientTreeNode[] };

        setRootNodes((prev) => {
          const next = structuredClone(prev) as ClientTreeNode[];
          const target = findNodeByPath(next, path);
          if (target) target.children = children;
          return next;
        });
      } catch (err) {
        console.error(`Failed to fetch children for ${path}:`, err);
      } finally {
        setLoadingPaths((prev) => {
          const next = new Set(prev);
          next.delete(path);
          return next;
        });
      }
    },
    [owner, repo, branch]
  );

  const toggleFolder = useCallback(
    (node: ClientTreeNode) => {
      setExpandedPaths((prev) => {
        const next = new Set(prev);
        if (next.has(node.path)) next.delete(node.path);
        else next.add(node.path);
        return next;
      });

      if (node.children === null || node.children === undefined) {
        void fetchChildren(node.path);
      }
    },
    [fetchChildren]
  );

  const runSearch = useCallback(
    async (query: string) => {
      setSearchQuery(query);

      if (!query.trim()) {
        setMatchedPaths(null);
        return;
      }

      searchAbortRef.current?.abort();
      const controller = new AbortController();
      searchAbortRef.current = controller;

      setIsSearching(true);
      try {
        const res = await fetch(
          `/api/repos/${owner}/${repo}/search?q=${encodeURIComponent(query)}&branch=${encodeURIComponent(branch)}`,
          { signal: controller.signal }
        );
        if (!res.ok) return;
        const { matches, ancestorPaths } = (await res.json()) as {
          matches: { path: string; type: string }[];
          ancestorPaths: string[];
        };

        setMatchedPaths(new Set(matches.map((m) => m.path)));
        setExpandedPaths((prev) => new Set([...prev, ...ancestorPaths]));

        for (const path of ancestorPaths) {
          const node = findNodeByPath(rootNodes, path);
          if (node && (node.children === null || node.children === undefined)) {
            void fetchChildren(path);
          }
        }
      } catch (err) {
        if ((err as Error).name !== "AbortError") console.error("Search failed:", err);
      } finally {
        setIsSearching(false);
      }
    },
    [owner, repo, branch, rootNodes, fetchChildren]
  );

  const rows = useMemo(
    () => flattenTree(rootNodes, expandedPaths, loadingPaths, matchedPaths),
    [rootNodes, expandedPaths, loadingPaths, matchedPaths]
  );

  return { rows, selectedPath, setSelectedPath, toggleFolder, searchQuery, runSearch, isSearching, matchedPaths };
}
