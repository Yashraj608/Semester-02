"use client";

import { useState, useCallback } from "react";
import type { ValidatedFile } from "@/lib/upload/validate-files";
import type { DestinationSuggestion } from "@/types/ai-suggestions";

const TEXT_PREVIEW_PATTERN = /\.(md|txt|json|ya?ml|ts|tsx|js|jsx|css|html|py|csv)$/i;

export function useSuggestDestinations(owner: string, repo: string, branch: string) {
  const [suggestions, setSuggestions] = useState<Record<string, DestinationSuggestion>>({});
  const [isLoading, setIsLoading] = useState(false);

  const fetchSuggestions = useCallback(
    async (files: ValidatedFile[]) => {
      setIsLoading(true);
      try {
        const payload = await Promise.all(
          files.map(async (f) => ({
            name: f.displayName,
            mimeType: f.file.type,
            sizeBytes: f.file.size,
            textPreview: TEXT_PREVIEW_PATTERN.test(f.displayName) ? (await f.file.text()).slice(0, 500) : undefined,
          }))
        );

        const res = await fetch(`/api/repos/${owner}/${repo}/suggest-destinations`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ files: payload, branch }),
        });
        if (!res.ok) throw new Error("Failed to get suggestions");

        const { suggestions: results } = (await res.json()) as { suggestions: DestinationSuggestion[] };
        setSuggestions(Object.fromEntries(results.map((s) => [s.fileName, s])));
      } catch (err) {
        console.error("Destination suggestion failed:", err);
      } finally {
        setIsLoading(false);
      }
    },
    [owner, repo, branch]
  );

  return { suggestions, fetchSuggestions, isLoading };
}
