import "server-only";

interface FileSummary {
  name: string;
  path: string;
  sizeBytes: number;
  textPreview?: string;
}

interface GenerateCommitMessageParams {
  files: FileSummary[];
  targetFolder: string;
}

const FALLBACK_TEMPLATE = (files: FileSummary[], folder: string) =>
  files.length === 1
    ? `Add ${files[0].name} to ${folder || "repository root"}`
    : `Add ${files.length} files to ${folder || "repository root"}`;

export async function generateCommitMessage({ files, targetFolder }: GenerateCommitMessageParams): Promise<{
  message: string;
  aiGenerated: boolean;
}> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return { message: FALLBACK_TEMPLATE(files, targetFolder), aiGenerated: false };

  const fileList = files
    .map((f) => `- ${f.path} (${formatBytes(f.sizeBytes)})${f.textPreview ? `\n  preview: ${f.textPreview.slice(0, 300)}` : ""}`)
    .join("\n");

  const prompt = `Write a single concise Git commit message (conventional commits style, imperative mood, no more than 72 characters on the summary line) for the following file upload:

Target folder: ${targetFolder || "repository root"}
Files:
${fileList}

Respond with ONLY the commit message text, nothing else.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_COMMIT_MODEL ?? "claude-sonnet-4-5",
        max_tokens: 100,
        messages: [{ role: "user", content: prompt }],
      }),
      signal: AbortSignal.timeout(8000),
    });

    if (!response.ok) throw new Error(`Anthropic API returned ${response.status}`);

    const data = await response.json();
    const text = data.content?.find((block: any) => block.type === "text")?.text?.trim();
    if (!text) throw new Error("Empty response from Anthropic API");

    return { message: text, aiGenerated: true };
  } catch (err) {
    console.error("AI commit message generation failed, using fallback:", err);
    return { message: FALLBACK_TEMPLATE(files, targetFolder), aiGenerated: false };
  }
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
}
