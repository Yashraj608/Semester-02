import "server-only";
import type { FolderProfile } from "@/lib/github/folder-profile";
import { formatFolderProfileForPrompt } from "@/lib/github/folder-profile";
import type { FileForSuggestion, DestinationSuggestion } from "@/types/ai-suggestions";

const SYSTEM_PROMPT = `You are a code organization assistant embedded in a GitHub tool.
Given a repository's existing folder structure and a list of newly uploaded files,
suggest the best destination folder for each file, based on the repository's own
conventions (not generic best practices).

Rules:
- Prefer an EXISTING folder from the provided structure when one clearly fits.
- Only propose a new folder path if no existing folder is a reasonable fit.
- Root-level files like README.md, LICENSE, .gitignore, package.json belong at the repository root ("").
- Images typically belong in an existing assets/images-style folder if one exists.
- Component files (.jsx, .tsx, .vue) belong near other component files of the same kind.
- Respond with ONLY a JSON array, no prose, no markdown fences. Each element:
  {"fileName": string, "suggestedFolder": string, "reasoning": string (max 20 words),
   "confidence": "high"|"medium"|"low", "alternativeFolders": string[] (0-2 items)}`;

export async function suggestDestinations(
  files: FileForSuggestion[],
  folderProfile: FolderProfile[],
  profileTruncated: boolean
): Promise<DestinationSuggestion[]> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return files.map((f) => fallbackSuggestion(f));

  const fileList = files
    .map((f) => `- ${f.name} (${f.mimeType || "unknown type"}, ${f.sizeBytes}B)${f.textPreview ? `\n  preview: ${f.textPreview.slice(0, 200)}` : ""}`)
    .join("\n");

  const userPrompt = `Existing repository folders (most populated first):
${formatFolderProfileForPrompt(folderProfile, profileTruncated)}

Files to place:
${fileList}`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_SUGGESTION_MODEL ?? "claude-sonnet-4-5",
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: userPrompt }],
      }),
      signal: AbortSignal.timeout(10000),
    });

    if (!response.ok) throw new Error(`Anthropic API returned ${response.status}`);

    const data = await response.json();
    const text = data.content?.find((block: any) => block.type === "text")?.text?.trim();
    if (!text) throw new Error("Empty response from Anthropic API");

    const cleaned = text.replace(/^```json\s*|\s*```$/g, "");
    const parsed = JSON.parse(cleaned) as DestinationSuggestion[];

    const byName = new Map(parsed.map((s) => [s.fileName, s]));
    return files.map((f) => byName.get(f.name) ?? fallbackSuggestion(f));
  } catch (err) {
    console.error("AI destination suggestion failed, using fallback:", err);
    return files.map((f) => fallbackSuggestion(f));
  }
}

function fallbackSuggestion(file: FileForSuggestion): DestinationSuggestion {
  const lower = file.name.toLowerCase();
  if (/^(readme|license|\.gitignore|package\.json)/i.test(lower)) {
    return { fileName: file.name, suggestedFolder: "", reasoning: "Standard root-level project file", confidence: "high", alternativeFolders: [] };
  }
  if (file.mimeType.startsWith("image/")) {
    return { fileName: file.name, suggestedFolder: "assets/images", reasoning: "Image files conventionally live in an assets folder", confidence: "low", alternativeFolders: [] };
  }
  return { fileName: file.name, suggestedFolder: "", reasoning: "Could not determine a specific location automatically", confidence: "low", alternativeFolders: [] };
}
