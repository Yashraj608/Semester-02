import NextAuth from "next-auth";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/db/prisma";
import { withTokenEncryption } from "./encrypted-adapter";
import { authConfig } from "./auth.config";

/**
 * Full auth config — Node-only. Adds the Prisma adapter (which pulls in the
 * `crypto` module for token encryption) on top of the edge-safe base config.
 * Used by API routes and server components, never by middleware.
 */
export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  adapter: withTokenEncryption(PrismaAdapter(prisma)),
});
