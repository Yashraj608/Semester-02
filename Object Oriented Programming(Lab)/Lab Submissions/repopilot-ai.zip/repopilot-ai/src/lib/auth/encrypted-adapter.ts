import type { Adapter, AdapterAccount } from "@auth/core/adapters";
import { encrypt } from "@/lib/crypto/token-encryption";

export function withTokenEncryption(base: Adapter): Adapter {
  return {
    ...base,
    async linkAccount(account: AdapterAccount): Promise<AdapterAccount | null | undefined> {
      const secured: AdapterAccount = {
        ...account,
        access_token: account.access_token ? encrypt(account.access_token) : account.access_token,
        refresh_token: account.refresh_token ? encrypt(account.refresh_token) : account.refresh_token,
      };
      const result = await base.linkAccount?.(secured);
      return result ?? undefined;
    },
  };
}
