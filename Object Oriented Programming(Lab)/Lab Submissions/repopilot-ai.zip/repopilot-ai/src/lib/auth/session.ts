import "server-only";
import { auth } from "@/lib/auth/auth";
import { prisma } from "@/lib/db/prisma";
import { decrypt } from "@/lib/crypto/token-encryption";
import { redirect } from "next/navigation";

export async function requireUser() {
  const session = await auth();
  if (!session?.user?.id) {
    redirect("/login");
  }
  return session.user;
}

export async function getGithubAccessToken(userId: string): Promise<string> {
  const account = await prisma.account.findFirst({
    where: { userId, provider: "github" },
    select: { access_token: true },
  });
  if (!account?.access_token) throw new Error("No GitHub account linked for this user");
  return decrypt(account.access_token);
}
