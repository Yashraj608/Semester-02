export function createLimiter(concurrency: number) {
  let active = 0;
  const queue: (() => void)[] = [];

  const runNext = () => {
    if (active >= concurrency || queue.length === 0) return;
    active++;
    const next = queue.shift()!;
    next();
  };

  return function limit<T>(fn: () => Promise<T>): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const task = () => {
        fn()
          .then(resolve)
          .catch(reject)
          .finally(() => {
            active--;
            runNext();
          });
      };
      queue.push(task);
      runNext();
    });
  };
}
