import "server-only";
import { Octokit } from "octokit";
import { getGithubAccessToken } from "@/lib/auth/session";

export async function createGithubClient(userId: string): Promise<Octokit> {
  const token = await getGithubAccessToken(userId);
  return new Octokit({ auth: token, userAgent: "RepoPilotAI/1.0" });
}
