export class BranchAlreadyExistsError extends Error {
  constructor(branch: string) {
    super(`Branch "${branch}" already exists — choose a different name`);
    this.name = "BranchAlreadyExistsError";
  }
}

export class NonFastForwardError extends Error {
  constructor(branch: string) {
    super(`Branch "${branch}" has moved since you loaded it — refresh and try again`);
    this.name = "NonFastForwardError";
  }
}

export class NoFilesToCommitError extends Error {
  constructor() {
    super("No files to commit — all files were skipped");
    this.name = "NoFilesToCommitError";
  }
}

export class CommitFailedError extends Error {
  constructor(message: string, public rolledBack: boolean) {
    super(message);
    this.name = "CommitFailedError";
  }
}
