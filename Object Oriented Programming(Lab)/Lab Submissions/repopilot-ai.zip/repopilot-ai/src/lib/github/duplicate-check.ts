import "server-only";
import type { Octokit } from "octokit";

export interface ExistingFileConflict {
  fileName: string;
  suggestedName: string;
}

export async function findExistingFileNames(
  octokit: Octokit,
  owner: string,
  repo: string,
  folder: string,
  branch: string
): Promise<Set<string>> {
  try {
    const response = await octokit.rest.repos.getContent({ owner, repo, path: folder, ref: branch });
    if (!Array.isArray(response.data)) return new Set();
    return new Set(response.data.filter((e) => e.type === "file").map((e) => e.name));
  } catch (err: any) {
    if (err.status === 404) return new Set();
    throw err;
  }
}

export function findConflicts(uploadFileNames: string[], existingNames: Set<string>): ExistingFileConflict[] {
  return uploadFileNames
    .filter((name) => existingNames.has(name))
    .map((name) => ({ fileName: name, suggestedName: suggestAvailableName(name, existingNames) }));
}

export function suggestAvailableName(originalName: string, existingNames: Set<string>): string {
  if (!existingNames.has(originalName)) return originalName;

  const dotIndex = originalName.lastIndexOf(".");
  const base = dotIndex === -1 ? originalName : originalName.slice(0, dotIndex);
  const ext = dotIndex === -1 ? "" : originalName.slice(dotIndex);

  let counter = 1;
  let candidate: string;
  do {
    candidate = `${base} (${counter})${ext}`;
    counter++;
  } while (existingNames.has(candidate));

  return candidate;
}
