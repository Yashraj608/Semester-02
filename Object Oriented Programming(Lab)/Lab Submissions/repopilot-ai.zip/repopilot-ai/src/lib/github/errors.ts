export class RepoNotFoundError extends Error {
  constructor(owner: string, repo: string) {
    super(`Repository ${owner}/${repo} not found or you don't have access to it`);
    this.name = "RepoNotFoundError";
  }
}

export class InsufficientPermissionsError extends Error {
  constructor(owner: string, repo: string) {
    super(`You don't have sufficient permissions on ${owner}/${repo}`);
    this.name = "InsufficientPermissionsError";
  }
}

export class InvalidRepoUrlError extends Error {
  constructor(input: string) {
    super(`"${input}" is not a valid GitHub repository URL`);
    this.name = "InvalidRepoUrlError";
  }
}

export class GithubApiError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = "GithubApiError";
  }
}
