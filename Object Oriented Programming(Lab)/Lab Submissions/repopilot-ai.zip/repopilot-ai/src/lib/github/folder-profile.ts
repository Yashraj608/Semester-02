import type { FlatTreeEntry } from "./tree";

export interface FolderProfile {
  path: string;
  depth: number;
  fileCount: number;
  extensionCounts: Record<string, number>;
}

const MAX_FOLDERS_IN_PROFILE = 150;

export function buildFolderProfile(entries: FlatTreeEntry[]): FolderProfile[] {
  const folders = new Map<string, FolderProfile>();
  folders.set("", { path: "", depth: 0, fileCount: 0, extensionCounts: {} });

  for (const entry of entries) {
    if (entry.type !== "blob") continue;

    const lastSlash = entry.path.lastIndexOf("/");
    const folderPath = lastSlash === -1 ? "" : entry.path.slice(0, lastSlash);
    const ext = getExtension(entry.path);

    if (!folders.has(folderPath)) {
      folders.set(folderPath, { path: folderPath, depth: folderPath ? folderPath.split("/").length : 0, fileCount: 0, extensionCounts: {} });
    }

    const profile = folders.get(folderPath)!;
    profile.fileCount++;
    profile.extensionCounts[ext] = (profile.extensionCounts[ext] ?? 0) + 1;
  }

  return Array.from(folders.values())
    .sort((a, b) => b.fileCount - a.fileCount)
    .slice(0, MAX_FOLDERS_IN_PROFILE);
}

function getExtension(path: string): string {
  const name = path.slice(path.lastIndexOf("/") + 1);
  const dotIndex = name.lastIndexOf(".");
  return dotIndex === -1 ? "(no extension)" : name.slice(dotIndex);
}

export function formatFolderProfileForPrompt(profiles: FolderProfile[], truncated: boolean): string {
  const lines = profiles.map((p) => {
    const topExtensions = Object.entries(p.extensionCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4)
      .map(([ext, count]) => `${ext}:${count}`)
      .join(", ");
    return `${p.path || "(root)"} — ${p.fileCount} files (${topExtensions})`;
  });

  if (truncated) lines.push(`… (${profiles.length} most populated folders shown; repository has more)`);

  return lines.join("\n");
}
