import "server-only";
import type { Octokit } from "octokit";
import { withRetry } from "./retry";
import { BranchAlreadyExistsError, NoFilesToCommitError, CommitFailedError } from "./commit-errors";

export type FileAction = "overwrite" | "rename" | "skip";
export interface FileResolution {
  action: FileAction;
  finalName?: string;
}

export interface ProgressEvent {
  type: "stage" | "file-progress" | "rollback" | "done" | "error";
  [key: string]: unknown;
}

interface CommitFilesParams {
  octokit: Octokit;
  owner: string;
  repo: string;
  baseBranch: string;
  newBranchName?: string | null;
  fileDestinations: Record<string, string>;
  commitMessage: string;
  files: File[];
  resolutions: Record<string, FileResolution>;
  emit: (event: ProgressEvent) => void;
}

class GitTransaction {
  private branchCreated: string | null = null;

  constructor(private octokit: Octokit, private owner: string, private repo: string) {}

  markBranchCreated(branch: string) {
    this.branchCreated = branch;
  }

  async rollback(emit: (event: ProgressEvent) => void): Promise<boolean> {
    if (!this.branchCreated) return false;
    try {
      emit({ type: "rollback", target: "branch", branch: this.branchCreated });
      await this.octokit.rest.git.deleteRef({ owner: this.owner, repo: this.repo, ref: `heads/${this.branchCreated}` });
      return true;
    } catch (rollbackErr) {
      console.error("Rollback failed — branch may need manual cleanup:", rollbackErr);
      return false;
    }
  }
}

export async function commitFilesWithProgress({
  octokit,
  owner,
  repo,
  baseBranch,
  newBranchName,
  fileDestinations,
  commitMessage,
  files,
  resolutions,
  emit,
}: CommitFilesParams) {
  const tx = new GitTransaction(octokit, owner, repo);

  try {
    emit({ type: "stage", stage: "resolving-branch" });
    const baseRef = await withRetry(() => octokit.rest.git.getRef({ owner, repo, ref: `heads/${baseBranch}` }));
    const baseCommitSha = baseRef.data.object.sha;

    let targetBranch = baseBranch;

    if (newBranchName) {
      emit({ type: "stage", stage: "creating-branch", branch: newBranchName });
      try {
        await withRetry(() =>
          octokit.rest.git.createRef({ owner, repo, ref: `refs/heads/${newBranchName}`, sha: baseCommitSha })
        );
      } catch (err: any) {
        if (err.status === 422) throw new BranchAlreadyExistsError(newBranchName);
        throw err;
      }
      tx.markBranchCreated(newBranchName);
      targetBranch = newBranchName;
    }

    const baseCommit = await withRetry(() => octokit.rest.git.getCommit({ owner, repo, commit_sha: baseCommitSha }));
    const baseTreeSha = baseCommit.data.tree.sha;

    const treeEntries: { path: string; mode: "100644"; type: "blob"; sha: string }[] = [];
    const total = files.length;
    let processed = 0;

    for (const file of files) {
      const resolution = resolutions[file.name] ?? { action: "overwrite" as const };

      if (resolution.action === "skip") {
        processed++;
        emit({ type: "file-progress", fileName: file.name, status: "skipped", processed, total });
        continue;
      }

      const finalName = resolution.action === "rename" && resolution.finalName ? resolution.finalName : file.name;

      emit({ type: "file-progress", fileName: file.name, status: "encoding", processed, total });
      const arrayBuffer = await file.arrayBuffer();
      const base64Content = Buffer.from(arrayBuffer).toString("base64");

      emit({ type: "file-progress", fileName: file.name, status: "uploading-blob", processed, total });
      const blob = await withRetry(() =>
        octokit.rest.git.createBlob({ owner, repo, content: base64Content, encoding: "base64" })
      );

      const destinationFolder = fileDestinations[file.name] ?? "";
      const path = destinationFolder ? `${destinationFolder}/${finalName}` : finalName;
      treeEntries.push({ path, mode: "100644", type: "blob", sha: blob.data.sha });

      processed++;
      emit({ type: "file-progress", fileName: file.name, status: "done", processed, total });
    }

    if (treeEntries.length === 0) throw new NoFilesToCommitError();

    emit({ type: "stage", stage: "creating-tree" });
    const tree = await withRetry(() =>
      octokit.rest.git.createTree({ owner, repo, base_tree: baseTreeSha, tree: treeEntries })
    );

    emit({ type: "stage", stage: "creating-commit" });
    const commit = await withRetry(() =>
      octokit.rest.git.createCommit({ owner, repo, message: commitMessage, tree: tree.data.sha, parents: [baseCommitSha] })
    );

    emit({ type: "stage", stage: "pushing" });
    try {
      await withRetry(() => octokit.rest.git.updateRef({ owner, repo, ref: `heads/${targetBranch}`, sha: commit.data.sha }));
    } catch (err: any) {
      if (err.status === 422) {
        const rolledBack = await tx.rollback(emit);
        throw new CommitFailedError(`${targetBranch} moved since you loaded it — refresh and try again`, rolledBack);
      }
      throw err;
    }

    return {
      commitSha: commit.data.sha,
      commitUrl: `https://github.com/${owner}/${repo}/commit/${commit.data.sha}`,
      branch: targetBranch,
      filesCommitted: treeEntries.length,
    };
  } catch (err) {
    if (!(err instanceof CommitFailedError)) {
      const rolledBack = await tx.rollback(emit);
      const message = err instanceof Error ? err.message : "Commit failed";
      throw new CommitFailedError(message, rolledBack);
    }
    throw err;
  }
}
