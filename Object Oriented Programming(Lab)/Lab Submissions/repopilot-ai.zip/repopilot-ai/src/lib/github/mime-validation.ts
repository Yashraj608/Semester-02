const ALLOWED_MIME_PREFIXES = ["image/", "text/"];
const ALLOWED_EXACT_MIME = ["application/pdf", "application/zip", "application/x-zip-compressed"];
const ALLOWED_EXTENSIONS = [
  ".txt", ".md", ".json", ".yml", ".yaml", ".ts", ".tsx", ".js", ".jsx",
  ".css", ".html", ".py", ".csv", ".log", ".zip", ".pdf",
];

export const MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024;

export function isAllowedFile(file: { name: string; type: string; size: number }): { ok: boolean; reason?: string } {
  if (file.size > MAX_FILE_SIZE_BYTES) {
    return { ok: false, reason: `${file.name} exceeds the 50MB limit` };
  }

  if (file.type) {
    if (ALLOWED_MIME_PREFIXES.some((p) => file.type.startsWith(p)) || ALLOWED_EXACT_MIME.includes(file.type)) {
      return { ok: true };
    }
  }

  const lower = file.name.toLowerCase();
  if (ALLOWED_EXTENSIONS.some((ext) => lower.endsWith(ext))) {
    return { ok: true };
  }

  return { ok: false, reason: `${file.name} is not an accepted file type` };
}
