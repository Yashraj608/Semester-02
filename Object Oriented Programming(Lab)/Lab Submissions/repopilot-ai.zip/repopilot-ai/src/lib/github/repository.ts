import "server-only";
import type { Octokit } from "octokit";
import { RepoNotFoundError, InsufficientPermissionsError, GithubApiError } from "./errors";

export interface RepositoryMetadata {
  id: number;
  owner: string;
  name: string;
  fullName: string;
  description: string | null;
  defaultBranch: string;
  isPrivate: boolean;
  htmlUrl: string;
  stargazersCount: number;
  size: number;
  permissions: { admin: boolean; push: boolean; pull: boolean };
}

export async function getRepositoryMetadata(
  octokit: Octokit,
  owner: string,
  repo: string,
  requiredPermission: "pull" | "push" = "pull"
): Promise<RepositoryMetadata> {
  let response;
  try {
    response = await octokit.rest.repos.get({ owner, repo });
  } catch (err: any) {
    if (err.status === 404) throw new RepoNotFoundError(owner, repo);
    throw new GithubApiError(err.message ?? "Failed to fetch repository", err.status);
  }

  const data = response.data;
  const permissions = data.permissions ?? { admin: false, push: false, pull: false };

  if (requiredPermission === "push" && !permissions.push) throw new InsufficientPermissionsError(owner, repo);
  if (requiredPermission === "pull" && !permissions.pull) throw new InsufficientPermissionsError(owner, repo);

  return {
    id: data.id,
    owner: data.owner.login,
    name: data.name,
    fullName: data.full_name,
    description: data.description,
    defaultBranch: data.default_branch,
    isPrivate: data.private,
    htmlUrl: data.html_url,
    stargazersCount: data.stargazers_count,
    size: data.size,
    permissions: { admin: permissions.admin, push: permissions.push, pull: permissions.pull },
  };
}
