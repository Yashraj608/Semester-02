export interface RetryOptions {
  maxAttempts?: number;
  baseDelayMs?: number;
}

function getRetryAfterMs(err: any): number | null {
  const retryAfter = err?.response?.headers?.["retry-after"];
  return retryAfter ? Number(retryAfter) * 1000 : null;
}

function isTransientError(err: any): boolean {
  const status = err?.status;
  if (status === 502 || status === 503 || status === 504) return true;
  if (status === 403 && /secondary rate limit|abuse/i.test(err?.message ?? "")) return true;
  return false;
}

export async function withRetry<T>(fn: () => Promise<T>, options: RetryOptions = {}): Promise<T> {
  const { maxAttempts = 3, baseDelayMs = 500 } = options;
  let lastError: unknown;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      if (!isTransientError(err) || attempt === maxAttempts) throw err;
      const retryAfterMs = getRetryAfterMs(err);
      const backoffMs = retryAfterMs ?? baseDelayMs * 2 ** (attempt - 1);
      await new Promise((resolve) => setTimeout(resolve, backoffMs));
    }
  }

  throw lastError;
}
