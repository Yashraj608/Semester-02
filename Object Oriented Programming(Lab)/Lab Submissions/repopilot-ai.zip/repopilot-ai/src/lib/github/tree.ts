import "server-only";
import type { Octokit } from "octokit";
import { GithubApiError } from "./errors";
import { createLimiter } from "@/lib/concurrency/limiter";

export type FlatTreeEntryType = "blob" | "tree";

export interface FlatTreeEntry {
  path: string;
  type: FlatTreeEntryType;
  sha: string;
  size?: number;
}

export interface TreeNode {
  name: string;
  path: string;
  type: "file" | "folder";
  sha: string;
  size?: number;
  children?: TreeNode[];
}

export interface FetchTreeResult {
  entries: FlatTreeEntry[];
  truncated: boolean;
  totalCount: number;
}

const FALLBACK_CONCURRENCY = 8;

export async function fetchFullTree(
  octokit: Octokit,
  owner: string,
  repo: string,
  branch: string
): Promise<FetchTreeResult> {
  const refResponse = await octokit.rest.git.getRef({ owner, repo, ref: `heads/${branch}` });
  const commitSha = refResponse.data.object.sha;

  const commitResponse = await octokit.rest.git.getCommit({ owner, repo, commit_sha: commitSha });
  const rootTreeSha = commitResponse.data.tree.sha;

  const fastResult = await tryFastRecursiveFetch(octokit, owner, repo, rootTreeSha);
  if (!fastResult.truncated) return fastResult;

  const entries = await walkTreeConcurrently(octokit, owner, repo, rootTreeSha);
  return { entries, truncated: false, totalCount: entries.length };
}

async function tryFastRecursiveFetch(
  octokit: Octokit,
  owner: string,
  repo: string,
  treeSha: string
): Promise<FetchTreeResult> {
  try {
    const response = await octokit.rest.git.getTree({ owner, repo, tree_sha: treeSha, recursive: "true" });
    const entries: FlatTreeEntry[] = response.data.tree
      .filter((e) => e.path && e.type && e.sha)
      .map((e) => ({ path: e.path!, type: e.type === "tree" ? "tree" : "blob", sha: e.sha!, size: e.size }));

    return { entries, truncated: response.data.truncated ?? false, totalCount: entries.length };
  } catch (err: any) {
    throw new GithubApiError(err.message ?? "Failed to fetch repository tree", err.status);
  }
}

async function walkTreeConcurrently(
  octokit: Octokit,
  owner: string,
  repo: string,
  rootTreeSha: string
): Promise<FlatTreeEntry[]> {
  const limit = createLimiter(FALLBACK_CONCURRENCY);
  const results: FlatTreeEntry[] = [];

  async function walk(treeSha: string, prefix: string): Promise<void> {
    const response = await octokit.rest.git.getTree({ owner, repo, tree_sha: treeSha, recursive: "false" });
    const subDirTasks: Promise<void>[] = [];

    for (const item of response.data.tree) {
      if (!item.path || !item.type || !item.sha) continue;
      const fullPath = prefix ? `${prefix}/${item.path}` : item.path;

      if (item.type === "tree") {
        results.push({ path: fullPath, type: "tree", sha: item.sha });
        subDirTasks.push(limit(() => walk(item.sha!, fullPath)));
      } else if (item.type === "blob") {
        results.push({ path: fullPath, type: "blob", sha: item.sha, size: item.size });
      }
    }

    await Promise.all(subDirTasks);
  }

  await walk(rootTreeSha, "");
  return results;
}

export function buildNestedTree(entries: FlatTreeEntry[]): TreeNode[] {
  const nodeByPath = new Map<string, TreeNode>();
  const root: TreeNode[] = [];

  for (const entry of entries) {
    const name = entry.path.slice(entry.path.lastIndexOf("/") + 1);
    const node: TreeNode = {
      name,
      path: entry.path,
      type: entry.type === "tree" ? "folder" : "file",
      sha: entry.sha,
      size: entry.size,
      children: entry.type === "tree" ? [] : undefined,
    };
    nodeByPath.set(entry.path, node);
  }

  for (const entry of entries) {
    const node = nodeByPath.get(entry.path)!;
    const lastSlash = entry.path.lastIndexOf("/");
    const parentPath = lastSlash === -1 ? null : entry.path.slice(0, lastSlash);

    if (parentPath === null) {
      root.push(node);
    } else {
      const parent = nodeByPath.get(parentPath);
      parent?.children?.push(node);
    }
  }

  sortTreeInPlace(root);
  return root;
}

function sortTreeInPlace(nodes: TreeNode[]): void {
  nodes.sort((a, b) => {
    if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  for (const node of nodes) {
    if (node.children) sortTreeInPlace(node.children);
  }
}
