import { InvalidRepoUrlError } from "./errors";

export interface ParsedRepoUrl {
  owner: string;
  repo: string;
}

export function parseGithubRepoUrl(input: string): ParsedRepoUrl {
  const trimmed = input.trim();

  const shorthandMatch = /^([\w.-]+)\/([\w.-]+)$/.exec(trimmed);
  if (shorthandMatch && !trimmed.includes("://") && !trimmed.includes("github.com")) {
    const [, owner, repo] = shorthandMatch;
    return { owner, repo: stripDotGit(repo) };
  }

  let normalized = trimmed;
  if (!/^https?:\/\//i.test(normalized)) {
    normalized = `https://${normalized}`;
  }

  let url: URL;
  try {
    url = new URL(normalized);
  } catch {
    throw new InvalidRepoUrlError(input);
  }

  if (!/(^|\.)github\.com$/i.test(url.hostname)) {
    throw new InvalidRepoUrlError(input);
  }

  const segments = url.pathname.split("/").filter(Boolean);
  if (segments.length < 2) {
    throw new InvalidRepoUrlError(input);
  }

  const [owner, rawRepo] = segments;
  const repo = stripDotGit(rawRepo);

  if (!owner || !repo) throw new InvalidRepoUrlError(input);

  return { owner, repo };
}

function stripDotGit(repo: string): string {
  return repo.endsWith(".git") ? repo.slice(0, -4) : repo;
}
