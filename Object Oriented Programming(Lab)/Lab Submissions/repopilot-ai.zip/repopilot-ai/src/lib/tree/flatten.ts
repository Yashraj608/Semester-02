import type { ClientTreeNode, FlattenedRow } from "./types";

export function flattenTree(
  nodes: ClientTreeNode[],
  expandedPaths: Set<string>,
  loadingPaths: Set<string>,
  matchedPaths: Set<string> | null,
  depth = 0
): FlattenedRow[] {
  const rows: FlattenedRow[] = [];

  for (const node of nodes) {
    const isExpanded = expandedPaths.has(node.path);
    const isLoading = loadingPaths.has(node.path);
    const isMatch = matchedPaths ? matchedPaths.has(node.path) : false;

    rows.push({ node, depth, isExpanded, isLoading, isMatch });

    if (node.type === "folder" && isExpanded && Array.isArray(node.children)) {
      rows.push(...flattenTree(node.children, expandedPaths, loadingPaths, matchedPaths, depth + 1));
    }
  }

  return rows;
}

export function findNodeByPath(nodes: ClientTreeNode[], path: string): ClientTreeNode | null {
  for (const node of nodes) {
    if (node.path === path) return node;
    if (node.children && Array.isArray(node.children)) {
      const found = findNodeByPath(node.children, path);
      if (found) return found;
    }
  }
  return null;
}
