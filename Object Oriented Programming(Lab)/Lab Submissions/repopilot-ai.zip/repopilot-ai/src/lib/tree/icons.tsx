import { Folder, FolderOpen, File, FileJson, FileCode, FileText, FileImage, FileCog, Braces, type LucideIcon } from "lucide-react";

interface IconSpec {
  Icon: LucideIcon;
  colorClass: string;
}

const EXTENSION_MAP: Record<string, IconSpec> = {
  ts: { Icon: FileCode, colorClass: "text-[#3178c6]" },
  tsx: { Icon: FileCode, colorClass: "text-[#3178c6]" },
  js: { Icon: FileCode, colorClass: "text-[#f0db4f]" },
  jsx: { Icon: FileCode, colorClass: "text-[#f0db4f]" },
  json: { Icon: FileJson, colorClass: "text-[#cbcb41]" },
  md: { Icon: FileText, colorClass: "text-[#8ab4f8]" },
  mdx: { Icon: FileText, colorClass: "text-[#8ab4f8]" },
  css: { Icon: Braces, colorClass: "text-[#563d7c]" },
  scss: { Icon: Braces, colorClass: "text-[#c6538c]" },
  html: { Icon: FileCode, colorClass: "text-[#e34c26]" },
  py: { Icon: FileCode, colorClass: "text-[#3572a5]" },
  png: { Icon: FileImage, colorClass: "text-[#a074c4]" },
  jpg: { Icon: FileImage, colorClass: "text-[#a074c4]" },
  jpeg: { Icon: FileImage, colorClass: "text-[#a074c4]" },
  svg: { Icon: FileImage, colorClass: "text-[#ffb13b]" },
  gif: { Icon: FileImage, colorClass: "text-[#a074c4]" },
  yml: { Icon: FileCog, colorClass: "text-[#858585]" },
  yaml: { Icon: FileCog, colorClass: "text-[#858585]" },
  env: { Icon: FileCog, colorClass: "text-[#858585]" },
  lock: { Icon: FileCog, colorClass: "text-[#858585]" },
  pdf: { Icon: FileText, colorClass: "text-[#e2574c]" },
  zip: { Icon: FileCog, colorClass: "text-[#e2b93b]" },
};

const SPECIAL_FILENAMES: Record<string, IconSpec> = {
  "package.json": { Icon: FileJson, colorClass: "text-[#cb3837]" },
  ".gitignore": { Icon: FileCog, colorClass: "text-[#858585]" },
  "readme.md": { Icon: FileText, colorClass: "text-[#8ab4f8]" },
};

export function getFileIcon(fileName: string): IconSpec {
  const lower = fileName.toLowerCase();
  if (SPECIAL_FILENAMES[lower]) return SPECIAL_FILENAMES[lower];

  const ext = lower.includes(".") ? lower.slice(lower.lastIndexOf(".") + 1) : "";
  return EXTENSION_MAP[ext] ?? { Icon: File, colorClass: "text-[#858585]" };
}

export function getFolderIcon(isExpanded: boolean): IconSpec {
  return { Icon: isExpanded ? FolderOpen : Folder, colorClass: "text-[#dcb67a]" };
}
