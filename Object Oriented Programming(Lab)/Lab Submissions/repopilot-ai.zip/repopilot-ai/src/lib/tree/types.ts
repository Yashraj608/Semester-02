export type TreeEntryType = "file" | "folder";

export interface ClientTreeNode {
  name: string;
  path: string;
  type: TreeEntryType;
  sha: string;
  size?: number;
  children?: ClientTreeNode[] | null;
}

export interface FlattenedRow {
  node: ClientTreeNode;
  depth: number;
  isExpanded: boolean;
  isLoading: boolean;
  isMatch: boolean;
}
