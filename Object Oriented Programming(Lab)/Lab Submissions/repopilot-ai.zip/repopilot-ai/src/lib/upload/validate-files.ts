import { isAllowedFile } from "@/lib/github/mime-validation";

export interface ValidatedFile {
  file: File;
  displayName: string;
}

export interface ValidationResult {
  accepted: ValidatedFile[];
  rejected: { name: string; reason: string }[];
}

export function validateAndDedupeBatch(files: File[]): ValidationResult {
  const accepted: ValidatedFile[] = [];
  const rejected: ValidationResult["rejected"] = [];
  const seenNames = new Map<string, number>();

  for (const file of files) {
    const check = isAllowedFile(file);
    if (!check.ok) {
      rejected.push({ name: file.name, reason: check.reason! });
      continue;
    }

    const count = seenNames.get(file.name) ?? 0;
    seenNames.set(file.name, count + 1);

    const displayName = count === 0 ? file.name : renameForBatchDuplicate(file.name, count);
    accepted.push({ file, displayName });
  }

  return { accepted, rejected };
}

function renameForBatchDuplicate(name: string, count: number): string {
  const dotIndex = name.lastIndexOf(".");
  const base = dotIndex === -1 ? name : name.slice(0, dotIndex);
  const ext = dotIndex === -1 ? "" : name.slice(dotIndex);
  return `${base} (${count})${ext}`;
}
