import { z } from "zod";

export const analyzeRepoSchema = z.object({
  repoUrl: z.string().min(1, "Repository URL is required").max(500),
  branch: z.string().max(255).optional(),
});

export type AnalyzeRepoInput = z.infer<typeof analyzeRepoSchema>;
