export interface FileForSuggestion {
  name: string;
  mimeType: string;
  sizeBytes: number;
  textPreview?: string;
}

export interface DestinationSuggestion {
  fileName: string;
  suggestedFolder: string;
  reasoning: string;
  confidence: "high" | "medium" | "low";
  alternativeFolders: string[];
}
