import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        explorer: {
          bg: "#1e1e1e",
          sidebar: "#252526",
          hover: "#2a2d2e",
          selected: "#37373d",
          border: "#3c3c3c",
          text: "#cccccc",
          muted: "#858585",
          accent: "#007acc",
        },
      },
      fontFamily: {
        ui: ["Segoe UI", "system-ui", "sans-serif"],
        mono: ["Menlo", "Consolas", "monospace"],
      },
    },
  },
  plugins: [],
};

export default config;
